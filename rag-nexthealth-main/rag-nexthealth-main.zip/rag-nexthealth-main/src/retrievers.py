"""
Módulo de retrievers avanzados para RAG NextHealth
Implementa multi-query retrieval, re-ranking con BGE, y fusion de resultados
"""

import os
from typing import List, Dict, Any, Optional
from pathlib import Path

from langchain_community.vectorstores import Chroma
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_community.chat_models import ChatOpenAI
from langchain.retrievers.multi_query import MultiQueryRetriever
from langchain.schema import Document
from langchain.prompts import PromptTemplate

try:
    from FlagEmbedding import FlagReranker
    BGE_AVAILABLE = True
except ImportError:
    BGE_AVAILABLE = False
    print("⚠️ FlagEmbedding no disponible. Usando re-ranking simple.")

try:
    from src.raptor import RAPTORRetriever, build_raptor_retriever
    RAPTOR_AVAILABLE = True
except ImportError:
    RAPTOR_AVAILABLE = False
    print("⚠️ RAPTOR no disponible.")

try:
    from src.advanced_rag import RAGFusionRetriever, HYDERetriever, build_fusion_retriever, build_hyde_retriever
    ADVANCED_RAG_AVAILABLE = True
except ImportError:
    ADVANCED_RAG_AVAILABLE = False
    print("⚠️ RAG-Fusion/HYDE no disponibles.")

try:
    from src.crag import CRAGRetriever, build_crag_retriever
    CRAG_AVAILABLE = True
except ImportError:
    CRAG_AVAILABLE = False
    print("⚠️ CRAG no disponible.")


def build_vectorstore(persist_dir: str) -> Optional[Chroma]:
    """
    Construye y carga el vector store desde el directorio de persistencia
    """
    if not Path(persist_dir).exists():
        print(f"❌ Vector store directory no encontrado: {persist_dir}")
        return None
    
    try:
        embeddings = HuggingFaceEmbeddings(
            model_name=os.getenv("EMBEDDINGS_MODEL", "intfloat/multilingual-e5-base"),
            model_kwargs={'device': 'cpu'},
            encode_kwargs={'normalize_embeddings': True}
        )
        
        vectorstore = Chroma(
            persist_directory=persist_dir,
            embedding_function=embeddings,
            collection_name="rag_nexthealth"
        )
        
        # Test the vectorstore
        test_results = vectorstore.similarity_search("test", k=1)
        print(f"✅ Vector store cargado exitosamente")
        
        return vectorstore
        
    except Exception as e:
        print(f"❌ Error cargando vector store: {str(e)}")
        return None


def create_multiquery_retriever(vectorstore: Chroma, llm=None, k: int = 8) -> MultiQueryRetriever:
    """
    Crea un MultiQueryRetriever que genera múltiples consultas para mejorar la recuperación
    """
    if llm is None:
        # the newest OpenAI model is "gpt-5" which was released August 7, 2025.
        # do not change this unless explicitly requested by the user
        llm = ChatOpenAI(
            model=os.getenv("OPENAI_CHAT_MODEL", "gpt-5"),
            api_key=os.getenv("OPENAI_API_KEY")
        )
    
    # Custom prompt for Spanish clinical queries
    QUERY_PROMPT = PromptTemplate(
        input_variables=["question"],
        template="""Eres un asistente médico especializado. Dada la siguiente pregunta clínica en español, 
        genera 3 versiones reformuladas que mantengan el mismo significado médico pero usen diferentes 
        terminología clínica, sinónimos y enfoques para maximizar la recuperación de información relevante.

        Pregunta original: {question}

        Reformulaciones:
        1.
        2.
        3.
        """
    )
    
    base_retriever = vectorstore.as_retriever(
        search_type="similarity",
        search_kwargs={"k": k}
    )
    
    multi_query_retriever = MultiQueryRetriever.from_llm(
        retriever=base_retriever, 
        llm=llm,
        prompt=QUERY_PROMPT
    )
    
    return multi_query_retriever


class BGEReranker:
    """
    Re-ranker usando BGE (BAAI General Embedding) para mejorar la relevancia
    """
    
    def __init__(self, model_name: str = "BAAI/bge-reranker-base"):
        self.model_name = model_name
        self.reranker = None
        
        if BGE_AVAILABLE:
            try:
                self.reranker = FlagReranker(model_name, use_fp16=False)
                print(f"✅ BGE Reranker cargado: {model_name}")
            except Exception as e:
                print(f"❌ Error cargando BGE reranker: {str(e)}")
                self.reranker = None
        else:
            print("⚠️ BGE no disponible, usando fallback simple")
    
    def rerank(self, query: str, documents: List[Document], top_k: int = 4) -> List[Document]:
        """
        Re-rankea documentos basado en relevancia a la consulta
        """
        if not documents:
            return []
        
        if self.reranker is None:
            # Simple fallback: ordenar por longitud del contenido (heurística básica)
            return self._simple_rerank(query, documents, top_k)
        
        try:
            # Prepare pairs for BGE reranker
            pairs = [[query, doc.page_content] for doc in documents]
            
            # Get scores
            scores = self.reranker.compute_score(pairs)
            
            # Handle single score vs list of scores
            if not isinstance(scores, list):
                scores = [scores]
            
            # Sort documents by score (descending)
            doc_score_pairs = list(zip(documents, scores))
            doc_score_pairs.sort(key=lambda x: x[1], reverse=True)
            
            # Return top_k documents
            reranked_docs = [doc for doc, score in doc_score_pairs[:top_k]]
            
            # Add rerank scores to metadata
            for i, (doc, score) in enumerate(doc_score_pairs[:top_k]):
                doc.metadata['rerank_score'] = float(score)
                doc.metadata['rerank_position'] = i + 1
            
            return reranked_docs
            
        except Exception as e:
            print(f"❌ Error en BGE reranking: {str(e)}")
            return self._simple_rerank(query, documents, top_k)
    
    def _simple_rerank(self, query: str, documents: List[Document], top_k: int) -> List[Document]:
        """
        Fallback simple reranking basado en heurísticas
        """
        def score_document(doc: Document) -> float:
            content = doc.page_content.lower()
            query_terms = query.lower().split()
            
            score = 0.0
            # Term frequency
            for term in query_terms:
                score += content.count(term)
            
            # Length penalty (prefer medium-length chunks)
            length_penalty = abs(len(content) - 800) / 1000
            score -= length_penalty
            
            # Medical terminology bonus
            medical_terms = ['diagnóstico', 'tratamiento', 'síntoma', 'paciente', 'clínico', 'médico']
            for term in medical_terms:
                if term in content:
                    score += 0.5
            
            return score
        
        # Score and sort documents
        scored_docs = [(doc, score_document(doc)) for doc in documents]
        scored_docs.sort(key=lambda x: x[1], reverse=True)
        
        # Add simple scores to metadata
        for i, (doc, score) in enumerate(scored_docs[:top_k]):
            doc.metadata['simple_score'] = score
            doc.metadata['rerank_position'] = i + 1
        
        return [doc for doc, score in scored_docs[:top_k]]


class FusionRetriever:
    """
    Implementa RAG-Fusion combinando resultados de múltiples estrategias de retrieval
    """
    
    def __init__(self, vectorstore: Chroma, reranker: BGEReranker = None):
        self.vectorstore = vectorstore
        self.reranker = reranker or BGEReranker()
    
    def retrieve_and_fuse(self, query: str, k: int = 8, final_k: int = 4) -> List[Document]:
        """
        Combina múltiples estrategias de retrieval y aplica fusion de resultados
        """
        all_docs = []
        doc_scores = {}
        
        try:
            # Strategy 1: Simple similarity search
            sim_docs = self.vectorstore.similarity_search(query, k=k)
            for i, doc in enumerate(sim_docs):
                doc_id = self._get_doc_id(doc)
                doc_scores[doc_id] = doc_scores.get(doc_id, 0) + (k - i) / k
                if doc_id not in [self._get_doc_id(d) for d in all_docs]:
                    all_docs.append(doc)
            
            # Strategy 2: MMR (Maximum Marginal Relevance)
            try:
                mmr_docs = self.vectorstore.max_marginal_relevance_search(query, k=k)
                for i, doc in enumerate(mmr_docs):
                    doc_id = self._get_doc_id(doc)
                    doc_scores[doc_id] = doc_scores.get(doc_id, 0) + (k - i) / k * 0.8
                    if doc_id not in [self._get_doc_id(d) for d in all_docs]:
                        all_docs.append(doc)
            except:
                pass  # MMR might not be available
            
            # Strategy 3: Search with different similarity threshold
            try:
                threshold_docs = self.vectorstore.similarity_search_with_score(query, k=k)
                for doc, score in threshold_docs:
                    if score < 1.5:  # Lower score = higher similarity
                        doc_id = self._get_doc_id(doc)
                        doc_scores[doc_id] = doc_scores.get(doc_id, 0) + (2.0 - score) / 2.0
                        if doc_id not in [self._get_doc_id(d) for d in all_docs]:
                            all_docs.append(doc)
            except:
                pass
            
            # Remove duplicates and sort by fusion score
            unique_docs = []
            seen_ids = set()
            
            for doc in all_docs:
                doc_id = self._get_doc_id(doc)
                if doc_id not in seen_ids:
                    doc.metadata['fusion_score'] = doc_scores.get(doc_id, 0)
                    unique_docs.append(doc)
                    seen_ids.add(doc_id)
            
            # Sort by fusion score
            unique_docs.sort(key=lambda x: x.metadata.get('fusion_score', 0), reverse=True)
            
            # Take top candidates for reranking
            fusion_candidates = unique_docs[:min(len(unique_docs), k)]
            
            # Apply reranking
            final_docs = self.reranker.rerank(query, fusion_candidates, final_k)
            
            return final_docs
            
        except Exception as e:
            print(f"❌ Error en fusion retrieval: {str(e)}")
            # Fallback to simple similarity search
            return self.vectorstore.similarity_search(query, k=final_k)
    
    def _get_doc_id(self, doc: Document) -> str:
        """
        Genera un ID único para el documento basado en su contenido y metadata
        """
        source = doc.metadata.get('source', 'unknown')
        page = doc.metadata.get('page', 0)
        content_hash = hash(doc.page_content[:100])  # Hash of first 100 chars
        return f"{source}_{page}_{content_hash}"


def build_advanced_retriever(persist_dir: str, use_fusion: bool = True) -> Optional[FusionRetriever]:
    """
    Construye el retriever avanzado con todas las funcionalidades
    """
    vectorstore = build_vectorstore(persist_dir)
    if vectorstore is None:
        return None
    
    reranker = BGEReranker()
    
    if use_fusion:
        return FusionRetriever(vectorstore, reranker)
    else:
        # Return simple wrapper for compatibility
        class SimpleRetriever:
            def __init__(self, vs, rr):
                self.vectorstore = vs
                self.reranker = rr
            
            def retrieve_and_fuse(self, query: str, k: int = 8, final_k: int = 4):
                docs = self.vectorstore.similarity_search(query, k=k)
                return self.reranker.rerank(query, docs, final_k)
        
        return SimpleRetriever(vectorstore, reranker)


# Backward compatibility functions
def simple_rerank(query: str, docs: List[Document], topk: int = 4) -> List[Document]:
    """
    Función de compatibilidad para re-ranking simple
    """
    reranker = BGEReranker()
    return reranker.rerank(query, docs, topk)


def multiquery_retriever(vectorstore, llm=None, k=8):
    """
    Función de compatibilidad para multi-query retriever
    """
    return create_multiquery_retriever(vectorstore, llm, k)


def build_raptor_enabled_retriever(persist_dir: str, use_raptor: bool = True) -> Optional[Any]:
    """
    Construye un retriever con soporte RAPTOR para consultas jerárquicas
    
    Args:
        persist_dir: Directorio del vector store
        use_raptor: Si True, usa RAPTOR; si False, usa retriever estándar
    
    Returns:
        RAPTORRetriever o FusionRetriever según configuración
    """
    vectorstore = build_vectorstore(persist_dir)
    if vectorstore is None:
        return None
    
    if use_raptor and RAPTOR_AVAILABLE:
        try:
            embeddings = HuggingFaceEmbeddings(
                model_name=os.getenv("EMBEDDINGS_MODEL", "intfloat/multilingual-e5-base"),
                model_kwargs={'device': 'cpu'},
                encode_kwargs={'normalize_embeddings': True}
            )
            
            raptor = build_raptor_retriever(
                vectorstore=vectorstore,
                embeddings_model=embeddings,
                max_documents=100,
                max_levels=3,
                cluster_size=10,
                top_k_per_level=2
            )
            
            if raptor:
                print("✅ RAPTOR retriever construido exitosamente")
                return raptor
            else:
                print("⚠️ Fallback a retriever estándar")
                return build_advanced_retriever(persist_dir)
                
        except Exception as e:
            print(f"❌ Error construyendo RAPTOR: {str(e)}")
            print("⚠️ Fallback a retriever estándar")
            return build_advanced_retriever(persist_dir)
    else:
        return build_advanced_retriever(persist_dir)


def build_advanced_rag_retriever(
    persist_dir: str,
    mode: str = "standard",
    llm: Optional[Any] = None
) -> Optional[Any]:
    """
    Construye un retriever con técnicas avanzadas de RAG
    
    Args:
        persist_dir: Directorio del vector store
        mode: Modo de recuperación:
            - "standard": FusionRetriever estándar
            - "raptor": RAPTOR jerárquico
            - "rag-fusion": RAG-Fusion con RRF
            - "hyde": HYDE con documentos hipotéticos
            - "hybrid": Combina múltiples técnicas
            - "crag": Corrective RAG con re-búsqueda automática
    
    Returns:
        Retriever configurado según el modo
    """
    vectorstore = build_vectorstore(persist_dir)
    if vectorstore is None:
        return None
    
    embeddings = HuggingFaceEmbeddings(
        model_name=os.getenv("EMBEDDINGS_MODEL", "intfloat/multilingual-e5-base"),
        model_kwargs={'device': 'cpu'},
        encode_kwargs={'normalize_embeddings': True}
    )
    
    try:
        if mode == "raptor" and RAPTOR_AVAILABLE:
            return build_raptor_enabled_retriever(persist_dir, use_raptor=True)
        
        elif mode == "rag-fusion" and ADVANCED_RAG_AVAILABLE:
            fusion_retriever = build_fusion_retriever(vectorstore, llm)
            print("✅ RAG-Fusion retriever construido")
            return fusion_retriever
        
        elif mode == "hyde" and ADVANCED_RAG_AVAILABLE:
            hyde_retriever = build_hyde_retriever(vectorstore, embeddings, llm)
            print("✅ HYDE retriever construido")
            return hyde_retriever
        
        elif mode == "crag" and CRAG_AVAILABLE:
            # CRAG envuelve al retriever estándar
            base_retriever = build_advanced_retriever(persist_dir)
            if base_retriever:
                crag_retriever = build_crag_retriever(base_retriever, threshold=0.6)
                print("✅ CRAG retriever construido (corrección automática)")
                return crag_retriever
            return None
        
        elif mode == "hybrid" and ADVANCED_RAG_AVAILABLE:
            # Wrapper que combina RAG-Fusion y HYDE
            class HybridRetriever:
                def __init__(self, vs, emb, llm_model):
                    self.fusion = build_fusion_retriever(vs, llm_model)
                    self.hyde = build_hyde_retriever(vs, emb, llm_model)
                    self.vectorstore = vs
                
                def retrieve(self, query: str, k: int = 5):
                    """Combina resultados de ambos métodos"""
                    # Recuperar con ambos
                    fusion_docs = self.fusion.retrieve_with_fusion(query, final_k=k)
                    hyde_docs = self.hyde.retrieve_with_hyde(query, k=k)
                    
                    # Combinar y deduplicar
                    all_docs = fusion_docs + hyde_docs
                    seen_ids = set()
                    unique_docs = []
                    
                    for doc in all_docs:
                        doc_id = hash(doc.page_content[:100])
                        if doc_id not in seen_ids:
                            seen_ids.add(doc_id)
                            unique_docs.append(doc)
                    
                    return unique_docs[:k]
            
            hybrid = HybridRetriever(vectorstore, embeddings, llm)
            print("✅ Hybrid (RAG-Fusion + HYDE) retriever construido")
            return hybrid
        
        else:
            # Fallback a retriever estándar
            return build_advanced_retriever(persist_dir)
    
    except Exception as e:
        print(f"❌ Error construyendo retriever avanzado: {str(e)}")
        return build_advanced_retriever(persist_dir)
