"""
RAG NextHealth - Sistema RAG avanzado para búsqueda clínica
"""

__version__ = "1.0.0"
