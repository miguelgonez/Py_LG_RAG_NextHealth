"""
Orquestación RAG con routing inteligente usando LangChain
Implementa el grafo de decisión entre vectorstore y SQL
"""

import os
from typing import Dict, Any, Optional

from langchain.prompts import PromptTemplate
from langchain_community.chat_models import ChatOpenAI
from langchain.schema.runnable import RunnableParallel, RunnableLambda
from langchain.schema import Document

from .retrievers import (
    build_advanced_retriever, 
    FusionRetriever, 
    build_raptor_enabled_retriever,
    build_advanced_rag_retriever
)
from .tools import analyze_sql_intent, get_sql_chain, run_sql
from .policies import DEFAULT_POLICY, format_response_with_policy


def create_routing_chain(
    persist_dir: str, 
    sqlite_path: str = None, 
    retrieval_mode: str = "standard"
):
    """
    Crea la cadena de routing que decide entre vectorstore y SQL
    
    Args:
        persist_dir: Directorio del vector store
        sqlite_path: Ruta a la base de datos SQL
        retrieval_mode: Modo de recuperación:
            - "standard": Retriever estándar con fusion y reranking
            - "raptor": RAPTOR jerárquico
            - "rag-fusion": RAG-Fusion con RRF
            - "hyde": HYDE con documentos hipotéticos
            - "hybrid": Combina múltiples técnicas
    """
    # Construir retriever según el modo
    retriever = build_advanced_rag_retriever(persist_dir, mode=retrieval_mode)
    
    if retriever is None:
        raise ValueError(f"No se pudo cargar el vector store desde {persist_dir}")
    
    # the newest OpenAI model is "gpt-5" which was released August 7, 2025.
    # do not change this unless explicitly requested by the user
    llm = ChatOpenAI(
        model=os.getenv("OPENAI_CHAT_MODEL", "gpt-5"),
        api_key=os.getenv("OPENAI_API_KEY")
    )
    
    def route_query(inputs: Dict[str, Any]) -> Dict[str, Any]:
        """
        Función de routing que decide si usar SQL o vectorstore
        """
        query = inputs["question"]
        
        # Analizar intención de la consulta
        intent_analysis = analyze_sql_intent(query)
        
        result = {
            "question": query,
            "route": intent_analysis["intent"],
            "confidence": intent_analysis["confidence"],
            "reasoning": intent_analysis["reasoning"]
        }
        
        try:
            if intent_analysis["intent"] == "sql" and sqlite_path:
                # Ruta SQL
                result["route_type"] = "SQL Query"
                sql_chain, db = get_sql_chain(sqlite_path)
                
                # Generar SQL
                generated_sql = sql_chain.invoke({"question": query})
                result["generated_sql"] = generated_sql
                
                # Ejecutar SQL
                df = run_sql(sqlite_path, generated_sql)
                
                if not df.empty:
                    # Convertir DataFrame a texto estructurado
                    result["sql_results"] = df.to_string(index=False)
                    result["documents"] = [
                        Document(
                            page_content=f"Resultados de consulta SQL:\n{df.to_string(index=False)}",
                            metadata={
                                "source": "SQL Database",
                                "sql_query": generated_sql,
                                "result_count": len(df),
                                "route": "sql"
                            }
                        )
                    ]
                else:
                    result["documents"] = [
                        Document(
                            page_content="No se encontraron resultados para la consulta SQL.",
                            metadata={"source": "SQL Database", "route": "sql"}
                        )
                    ]
            
            else:
                # Ruta Vectorstore - detectar tipo de retriever
                result["route_type"] = "Vector Search"
                
                # Determinar método de recuperación basado en los atributos del retriever
                if hasattr(retriever, 'retrieve_with_correction'):
                    # CRAG retriever con corrección
                    docs, crag_metadata = retriever.retrieve_with_correction(query, k=4)
                    result["route_type"] = "CRAG (Corrective)"
                    result["crag_metadata"] = crag_metadata
                    if crag_metadata.get("correction_applied"):
                        result["route_type"] += f" - {crag_metadata['iterations']} iteraciones"
                elif hasattr(retriever, 'retrieve_with_fusion'):
                    # RAG-Fusion retriever
                    docs = retriever.retrieve_with_fusion(query, final_k=4)
                    result["route_type"] = "RAG-Fusion (RRF)"
                elif hasattr(retriever, 'retrieve_with_hyde'):
                    # HYDE retriever
                    docs = retriever.retrieve_with_hyde(query, k=4)
                    result["route_type"] = "HYDE (Hypothetical)"
                elif hasattr(retriever, 'retrieve') and not hasattr(retriever, 'retrieve_and_fuse'):
                    # RAPTOR retriever (usa total_k) o HybridRetriever (usa k)
                    # Intentar con total_k primero (RAPTOR), luego k (Hybrid)
                    try:
                        docs = retriever.retrieve(query, total_k=4)
                    except TypeError:
                        docs = retriever.retrieve(query, k=4)
                    result["route_type"] = "Advanced Hierarchical Search"
                elif hasattr(retriever, 'retrieve_and_fuse'):
                    # FusionRetriever estándar
                    docs = retriever.retrieve_and_fuse(query, k=8, final_k=4)
                else:
                    # Fallback simple
                    docs = retriever.vectorstore.similarity_search(query, k=4)
                
                result["documents"] = docs
                
                # Agregar metadata de routing
                for doc in docs:
                    if "route" not in doc.metadata:
                        doc.metadata["route"] = "vector"
        
        except Exception as e:
            # Fallback a vectorstore en caso de error
            print(f"⚠️ Error en routing, usando fallback: {str(e)}")
            result["route_type"] = "Vector Search (Fallback)"
            result["error"] = str(e)
            
            try:
                if hasattr(retriever, 'retrieve_with_correction'):
                    docs, _ = retriever.retrieve_with_correction(query, k=4)
                elif hasattr(retriever, 'retrieve_with_fusion'):
                    docs = retriever.retrieve_with_fusion(query, final_k=4)
                elif hasattr(retriever, 'retrieve_with_hyde'):
                    docs = retriever.retrieve_with_hyde(query, k=4)
                elif hasattr(retriever, 'retrieve'):
                    # Intentar con total_k primero (RAPTOR), luego k (Hybrid)
                    try:
                        docs = retriever.retrieve(query, total_k=4)
                    except TypeError:
                        docs = retriever.retrieve(query, k=4)
                elif hasattr(retriever, 'retrieve_and_fuse'):
                    docs = retriever.retrieve_and_fuse(query, k=8, final_k=4)
                else:
                    docs = retriever.vectorstore.similarity_search(query, k=4)
                result["documents"] = docs
            except:
                result["documents"] = [
                    Document(
                        page_content="Error: No se pudo procesar la consulta.",
                        metadata={"source": "Error", "route": "error"}
                    )
                ]
        
        return result
    
    # Crear la cadena completa
    routing_chain = RunnableLambda(route_query)
    
    return routing_chain


def build_rag_chain(
    persist_dir: str, 
    sqlite_path: str = "./db/icpc3.db", 
    use_raptor: bool = False,
    retrieval_mode: str = None
):
    """
    Construye la cadena RAG completa con routing inteligente
    
    Args:
        persist_dir: Directorio del vector store
        sqlite_path: Ruta a la base de datos SQL
        use_raptor: Si True, usa RAPTOR (deprecated, use retrieval_mode)
        retrieval_mode: Modo de recuperación explícito ("standard", "raptor", "rag-fusion", "hyde", "hybrid")
    """
    # the newest OpenAI model is "gpt-5" which was released August 7, 2025.
    # do not change this unless explicitly requested by the user
    llm = ChatOpenAI(
        model=os.getenv("OPENAI_CHAT_MODEL", "gpt-5"),
        api_key=os.getenv("OPENAI_API_KEY")
    )
    
    # Determinar modo de recuperación
    if retrieval_mode is None:
        retrieval_mode = "raptor" if use_raptor else "standard"
    
    # Crear el routing chain con modo de recuperación avanzado
    router = create_routing_chain(persist_dir, sqlite_path, retrieval_mode=retrieval_mode)
    
    # Prompt para generación de respuesta con guardarraíles
    RESPONSE_PROMPT = PromptTemplate.from_template(
        """Eres un asistente médico especializado que ayuda con información clínica en español.

        INSTRUCCIONES IMPORTANTES:
        {policy_instructions}

        CONTEXTO RECUPERADO:
        Método de búsqueda: {route_type}
        Confianza del routing: {confidence:.2f}
        
        Fragmentos de información:
        {documents}

        PREGUNTA DEL USUARIO: {question}

        INSTRUCCIONES ESPECÍFICAS:
        - Responde SIEMPRE en español claro y profesional
        - Usa únicamente la información de los fragmentos proporcionados
        - Estructura tu respuesta en puntos claros
        - Incluye citas específicas de las fuentes
        - Si la información es insuficiente, indícalo claramente
        - Para resultados de SQL, presenta los datos de forma clara y estructurada
        - Añade siempre el disclaimer médico al final

        RESPUESTA:"""
    )
    
    def format_documents(docs):
        """Formatea documentos para el prompt"""
        if not docs:
            return "No se encontraron documentos relevantes."
        
        formatted = []
        for i, doc in enumerate(docs):
            source = doc.metadata.get('source', 'Desconocido')
            route = doc.metadata.get('route', 'unknown')
            
            if route == 'sql':
                formatted.append(f"[FUENTE SQL {i+1}] Base de datos médica:\n{doc.page_content}")
            else:
                page = doc.metadata.get('page', '')
                page_info = f" (página {page})" if page else ""
                formatted.append(f"[FUENTE {i+1}] {source}{page_info}:\n{doc.page_content}")
        
        return "\n\n".join(formatted)
    
    def generate_response(router_output: Dict[str, Any]) -> Dict[str, Any]:
        """Genera la respuesta final usando el LLM"""
        try:
            documents = router_output.get("documents", [])
            formatted_docs = format_documents(documents)
            
            # Preparar el prompt
            prompt_input = {
                "policy_instructions": DEFAULT_POLICY.get_instructions(),
                "question": router_output["question"],
                "documents": formatted_docs,
                "route_type": router_output.get("route_type", "Unknown"),
                "confidence": router_output.get("confidence", 0.0)
            }
            
            # Generar respuesta
            prompt = RESPONSE_PROMPT.format(**prompt_input)
            response = llm.invoke(prompt)
            
            # Aplicar políticas de salida
            final_response = format_response_with_policy(
                response.content,
                documents,
                router_output.get("route", "unknown"),
                DEFAULT_POLICY
            )
            
            return {
                "response": final_response,
                "metadata": {
                    "route_used": router_output.get("route", "unknown"),
                    "route_type": router_output.get("route_type", "Unknown"),
                    "confidence": router_output.get("confidence", 0.0),
                    "documents_count": len(documents),
                    "sources": [doc.metadata.get('source', 'Unknown') for doc in documents],
                    "sql_query": router_output.get("generated_sql", None)
                }
            }
        
        except Exception as e:
            error_response = f"❌ Error generando respuesta: {str(e)}\n\n{DEFAULT_POLICY.disclaimer}"
            return {
                "response": error_response,
                "metadata": {
                    "error": str(e),
                    "route_used": "error"
                }
            }
    
    # Crear la cadena completa
    rag_chain = (
        router
        | RunnableLambda(generate_response)
    )
    
    # Wrapper para compatibilidad con la interfaz esperada
    class RAGChainWrapper:
        def __init__(self, chain):
            self.chain = chain
        
        def invoke(self, inputs: Dict[str, Any]):
            result = self.chain.invoke(inputs)
            
            # Crear objeto similar a ChatMessage para compatibilidad
            class ResponseMessage:
                def __init__(self, content):
                    self.content = content
            
            return ResponseMessage(result["response"])
        
        def get_metadata(self, inputs: Dict[str, Any]):
            """Método adicional para obtener metadata"""
            result = self.chain.invoke(inputs)
            return result.get("metadata", {})
    
    return RAGChainWrapper(rag_chain)


def create_simple_rag_chain(persist_dir: str):
    """
    Crea una cadena RAG simple sin routing (solo vectorstore)
    Para casos donde no se necesita funcionalidad SQL
    """
    retriever = build_advanced_retriever(persist_dir)
    
    if retriever is None:
        raise ValueError(f"No se pudo cargar el vector store desde {persist_dir}")
    
    # the newest OpenAI model is "gpt-5" which was released August 7, 2025.
    # do not change this unless explicitly requested by the user
    llm = ChatOpenAI(
        model=os.getenv("OPENAI_CHAT_MODEL", "gpt-5"),
        api_key=os.getenv("OPENAI_API_KEY")
    )
    
    SIMPLE_PROMPT = PromptTemplate.from_template(
        """Eres un asistente médico que responde preguntas sobre información clínica en español.

        INSTRUCCIONES:
        - Responde únicamente basándote en el contexto proporcionado
        - Mantén un tono profesional y claro
        - Estructura la información en puntos
        - Incluye referencias a las fuentes
        - Si no tienes información suficiente, dilo claramente

        CONTEXTO:
        {documents}

        PREGUNTA: {question}

        RESPUESTA (en español):"""
    )
    
    def format_docs(docs):
        if not docs:
            return "No se encontró información relevante."
        
        return "\n\n".join([
            f"[Fuente {i+1}] {doc.metadata.get('source', 'Documento')}:\n{doc.page_content}"
            for i, doc in enumerate(docs)
        ])
    
    simple_chain = (
        RunnableParallel({
            "question": lambda x: x["question"],
            "documents": lambda x: retriever.retrieve_and_fuse(x["question"], k=8, final_k=4)
        })
        | RunnableLambda(lambda x: {
            "question": x["question"],
            "documents": format_docs(x["documents"])
        })
        | SIMPLE_PROMPT
        | llm
    )
    
    return simple_chain
